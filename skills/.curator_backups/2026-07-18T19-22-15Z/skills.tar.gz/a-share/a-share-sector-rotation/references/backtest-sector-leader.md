# 板块TOP3上榜后龙头股持有期回测

## 回测框架

脚本: `scripts/backtest_sector_leader.py`
数据源: THS板块排行 + `ths_member`成分映射 + `moneyflow_daily.net_mf_amt`(个股主力净流入) + `daily_kline.close`(股价)

## 策略

当某概念板块出现在每日净流入TOP3时，在收盘买入该板块的龙头股
（板块内当日主力净流入最大的1~3只成分股），持有N个交易日后卖出。

## 关键修复

### 1. moneyflow_daily 资金列名
`moneyflow_daily` 表中有效的主力资金列是 `net_mf_amt`。
`main_net_amt` 全部为 NULL（非原数据来源）。

### 2. 日期格式统一
- `sector_moneyflow_ths.trade_date`: YYYYMMDD
- `moneyflow_daily.date`: YYYY-MM-DD
- `daily_kline.date`: YYYY-MM-DD
查询时用 `fmt_date()` 做统一转换。

### 3. 过滤宽基指数板块
有效分析需排除融资融券/沪股通/深股通/MSCI等宽基指数型板块。
这些板块成分股过多且非真实概念板块。

### 4. 移除 `moneyflow_daily.close`
`moneyflow_daily` 无 `close` 列，股价需从 `daily_kline` 单独查询。

### 5. 回测框架结构
`BacktestEngine` 类:
- `get_top_sectors()`: 获当日TOP3板块（排除指数型）
- `get_leader_stocks()`: 查成员+净流入最大的N只
- `get_holding_returns()`: 查daily_kline算持有期收益率
- `run(hold_days, top_n)`: 跑单一参数组合
- `run_all()`: 遍历所有组合
- `_calc_stats()`: 计算胜率/夏普/最大回撤等
- `analyze_by_sector()`: 按板块汇总

## 推荐参数: H20_T3

持有20个交易日，每板块买Top3龙头:
- 胜率 73.4%
- 平均收益 +14.46%
- 夏普比率 1.69
- 盈亏比 6.77

最佳板块: 芯片概念(86.5%胜率)、5G(82.6%)、数据中心(92.3%)
