# 晨报 v5 / v5.1 — Self-Contained Python Report Pattern

## Architecture

### v5 (original): no_agent=true, pure script

```
07:00 → cron runs daily_morning_report_v5.py (no_agent=true)
       → script queries stock_data.db (SQLite) + 1 curl call for index API
       → stdout is the complete report
       → cron delivers directly to WeChat via deliver=origin
```

### v5.1 (agent-driven with market data + session review) — Superseded 2026-07-04

```
07:02 → Agent runs (no_agent=false)
       → Step 1: Execute daily_morning_report_v5.sh to get market data stdout
       → Step 2: session_search for yesterday's conversations
       → Step 3: Check memory for recent entries
       → Step 4: Check skills for recent creations/updates
       → Compile: market data + interaction summary + memory/skill changelog
       → Deliver to WeChat via deliver=weixin
```

**Why v5.1**: Added context-awareness — the agent can look back at yesterday's interactions and report what was learned (memory entries, new skills). Pure scripts can't do this.

**Trade-off**: v5.1 uses more tokens per run (agent overhead) but adds "昨日工作回顾" and "Memory/Skill 变更" sections that provide daily learning accountability.

## Cron Integration

### v5 (original, script-only)

```bash
hermes cron action=update \
  job_id="3841106d9ea2" \
  script="daily_morning_report_v5.py" \
  no_agent=true \
  deliver=origin \
  schedule="0 7 * * *"
```

### v5.1 (agent-driven, current)

```bash
hermes cron action=update \
  job_id="3841106d9ea2" \
  no_agent=false \
  deliver=weixin \
  schedule="2 7 * * *" \
  prompt="# 每日晨报任务...

步骤：
1. 运行 daily_morning_report_v5.sh 获取市场数据
2. session_search 查昨日会话
3. 检查 memory 和 skill 变更
4. 整合推送"
```

Key differences:
- `no_agent=true` → `no_agent=false`
- `script="..."` → `prompt="..."` with step-by-step instructions
- Schedule: `0 7 * * *` → `2 7 * * *` (02 min past to avoid :00 congestion)
- `deliver=origin` → `deliver=weixin`

### v5.2 (current): no_agent=false, review-only (no market data)

**Transition on 2026-07-04**: User requested removal of all market data modules (大盘概况, 资金流向, 自选股表现). Morning report reduced to pure interaction review + memory/skill changelog.

```bash
hermes cron action=update \
  job_id="3841106d9ea2" \
  no_agent=false \
  deliver=weixin \
  schedule="2 7 * * *" \
  prompt="# 每日晨报任务...

步骤：
1. session_search 查昨日会话（周一需回溯3天）
2. 检查 memory 变更
3. 检查 skill 变更
4. 整合推送：仅昨日回顾 + memory/skill 变更"
```

**Key changes from v5.1:**
- Removed `Step 1: Run daily_morning_report_v5.sh` (no market data needed)
- Refined session_search with Monday/weekend fallback
- Added memory probe + skills count patterns (not "what's new" since cron has no baseline)
- Output format reduced to 2 sections (昨日工作回顾, Memory/Skill变更)
- No data-collection script needed — pure agent orchestration
- `script` field cleared from cron config to avoid confusion

**Why v5.2**: When the user no longer needs market data in the morning push, removing the script dependency reduces cron complexity to zero. The report becomes purely about learning accountability — what was done yesterday, what was remembered, what skills were created.

## Why v5 Replaced v4

| Aspect | v4 (retired) | v5 (current) |
|--------|-------------|--------------|
| Engine | bash + grep logs | Python + SQLite |
| Data source | Pipeline log files | `stock_data.db` (daily_kline, moneyflow_daily, watchlist) |
| Index data | None | Sina finance API (lightweight curl) |
| Retry queue | 3 crons (07:02, 08:00, 09:00) + delivery_retry.sh | None needed |
| Output | Log status lines | Real market data: indices, moneyflow, watchlist |
| Delivery | Pending file → retry cron → push | Direct stdout → deliver=origin |

**Key insight**: the v4 retry queue existed because the pipeline logs were unreliable (often missing/failed overnight). v5 depends on the DB, which is more deterministic — either the data is there or it isn't. Retrying 1h later doesn't fix missing DB data.

## Data Sources (in priority order)

### 1. Local SQLite (`stock_data.db`)

| Table | What it provides | Fields used |
|-------|-----------------|-------------|
| `daily_kline` | Stock close prices, pct_change | `stock_code, date, close, pct_change` |
| `moneyflow_daily` | Main/retail net flows | `date, stock_code, main_net_amt, net_mf_amt` |
| `watchlist` | Self-select stock groups | `stock_code, stock_name, group_id, group_name` |
| `wl_groups` | Sector/industry groups | `group_id, group_name` |
| `index_daily` | Index daily data (sparse) | `ts_code, trade_date, close, pct_chg` |

### 2. Sina Finance API (curl fallback for indices)

Only for the 4 major indices not in `index_daily`:
- 上证指数 (000001.SH)
- 深证成指 (399001.SZ)
- 创业板指 (399006.SZ)
- 科创50 (000688.SH)

**Endpoint:** `https://hq.sinajs.cn/list=s_sh000001,s_sz399001,s_sz399006,s_sh000688`

**Format:** `var hq_str_s_sh000001="指数名,开盘,昨收,最新价,涨跌额,涨跌幅%,..."`

Field 4 = latest price, field 5 = change amount, field 6 = change % (string like `+1.23`)

**Pitfall:** Sina might block requests without `User-Agent: Mozilla/5.0`. Set curl timeout to 5s; on failure, show "数据暂缺".

### 3. `index_daily` table (only has HS300)

The `index_daily` table in stock_data.db only contains `000300.SH` (沪深300). The 4 major indices are not loaded. If a custom pipeline loads them later, `index_daily` takes priority over the Sina curl.

## Module Structure

| Module | Emoji | Data source | Key output |
|--------|-------|-------------|------------|
| 大盘概况 | 📊 | Sina API (curl) + index_daily | Table: index name, close, pct |
| 行业板块 | 🏭 | wl_groups + daily_kline | Table: group, stock count, >2%/<2% counts, leader |
| 资金流向 | 💰 | moneyflow_daily | Table: main net, total net + TOP5 movers |
| 自选股表现 | 🏆 | watchlist + daily_kline | Summary stats + top 5 / bottom 5 |
| 数据采集状态 | ⚙️ | ~/.logs/ file timestamps | Table: pipeline name, age, emoji status |

## Output Constraints for WeChat

- **No full watchlist table** — 105 stocks = unreadable on mobile. Keep only: summary line + 🔥 top 5 + 💧 bottom 5.
- **emoji + table format** — one emoji prefix per section, markdown tables for structured data.
- **Error display** — section shows "数据暂缺" instead of an empty table when data unavailable. Never crash.

## Cron Integration

```bash
# Create (or update existing "每日晨报采集" job)
hermes cron action=update \
  job_id="3841106d9ea2" \
  script="daily_morning_report_v5.py" \
  no_agent=true \
  deliver=origin \
  schedule="0 7 * * *"

# Delete old retry crons (no longer needed)
hermes cron action=remove job_id="<晨报补推-上午>"
hermes cron action=remove job_id="<晨报补推-下午>"
```

## Cleanup After Pipeline Redesign

When replacing a data pipeline pattern (v4 → v5), always:

1. **Stop the old producers first** — pause or remove the cron jobs that generate intermediate artifacts (pending files, retry crons).
2. **Update the main cron** — point at the new script.
3. **Clean up dead cron jobs** — use `cronjob action=remove` on retry/fallback crons that no longer serve a purpose.
4. **Update memory** — remove stale cron-push rules from persistent memory.
5. **Archive (don't delete) old scripts** — the v4 script stays on disk for reference, but mark it as [DEPRECATED] in skill docs so future sessions know not to use it.
