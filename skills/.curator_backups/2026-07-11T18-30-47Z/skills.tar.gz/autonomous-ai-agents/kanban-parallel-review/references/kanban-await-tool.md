# kanban_await.py — 自动推送工具

## 位置

`~/my_quant_system/scripts/kanban_await.py`

## 用途

创建 Kanban 卡后，自动轮询等待完成并推送结果到终端。替代手动 `kanban list` + `kanban show`。

## 依赖

- `hermes CLI` 在 PATH 中
- 使用 `hermes kanban show --json`（结构化API），不依赖文本格式，防止版本升级后正则断掉

## 用法

```bash
# 等待单张卡
python kanban_await.py t_xxx

# 等待多张卡（worker评审卡同时等）
python kanban_await.py t_glm t_kimi t_auditor

# 自定义超时（默认600s）和间隔（默认15s）
python kanban_await.py t_xxx --timeout 300 --interval 10
```

## JSON 解析格式

`hermes kanban show --json` 返回结构：

```json
{
  "task": {"id": "t_xxx", "title": "标题", "status": "done"},
  "latest_summary": "摘要文本",
  "events": [...]
}
```

脚本扁平化为：`status ← task.status`, `title ← task.title`, `summary ← latest_summary`

## 失败模式

| 场景 | 脚本行为 | 退出码 |
|------|----------|:------:|
| 全部完成 | 打印所有摘要 | 0 |
| 部分失败 | 打印 done 的摘要，标记 failed | 0 |
| 全部超时 | 打印各卡最终状态 | 1 |
| hermes CLI 不可用 | 持续重试直到超时 | 1 |
