---
name: a-share-sector-rotation
description: >-
  A股板块轮动数据分析基础设施 — 从数据采集（ths_member板块成分股映射、
  板块资金流向）、历史回填、每日增量cron，到L1-L3三层决策框架的搭建。
  Use when 用户要求做板块轮动分析、找热门板块、龙头股识别、设置板块资金流数据管线、
  或搭建三层决策系统（大盘温度→板块轮动→估值门控）。
---

# A股板块轮动数据基础设施

> 基于 Tushare MCP + Hermes cron 的全链路板块数据分析管线

## 数据管线概览

```
Tushare MCP / Python SDK
    │
    ├── ths_index(type=N) → 概念板块列表 (885xxx.TI, 886xxx.TI)
    ├── ths_index(type=I) → 行业板块列表 (881xxx.TI)
    ├── ths_member(ts_code) → 板块→成分股映射表 (ths_member表, 472板块/71K行)
    │
    ├── moneyflow_cnt_ths(date) → 概念板块资金流向 (sector_moneyflow_ths表)
    ├── moneyflow_ind_ths(date) → 行业板块资金流向 (industry_moneyflow_ths表)
    ├── moneyflow_mkt_dc(date) → 大盘资金流 (market_moneyflow表)
    ├── moneyflow_hsgt(date) → 北向资金 (hsgt_moneyflow表)
    └── index_daily → 5指数日线
            │
            ▼
    ┌───────────────┐
    │  stock_data.db │
    │  SQLite 6.5GB  │
    └───────┬───────┘
            │
    ┌───────┴──────────────────────┐
    │                              │
    ▼                              ▼
  L1: engines/market_temperature.py   L2: engines/sector_rotation.py
  (大盘温度评分, 3维度合成)            (板块热度评分+龙头识别)
       │                                    │
       └────────────────┬───────────────────┘
                        ▼
                  L3: valuation_check
                  (PE通道估值门控, 待实现)
```

## 每日数据管道时间线

```
18:00  前复权日线 + 指数日线 (批量cron)
18:30  大盘资金流 + 北向资金 (daily_market_moneyflow.py)
18:45  概念+行业板块资金流 (daily_sector_moneyflow.py)
19:00  大盘温度计算 L1 (engines/market_temperature.py)
20:00  板块轮动 L2 (engines/sector_rotation.py)
```

## 引擎架构

### L1: 大盘温度引擎 (`engines/market_temperature.py`, ~680行)

类 `MarketTemperatureEngine`:
- `calc_index_trend(date)` → 5指数均线排列(60%)+价格位置(30%)+MACD(10%)
- `calc_capital_flow(date)` → 主力资金(50%)+北向(35%)+两融(15%/跳过)
- `calc_sentiment(date)` → 涨跌比(35%)+涨停数(25%)+连板(15%)+量能(25%)
- `run(date)` → 合成写入 `market_temperature` 表

**关键修复**:
- hsgt_moneyflow `north_total` 单位万元→亿元
- 日期兼容 `YYYY-MM-DD` 和 `YYYYMMDD` 双格式
- MACD用 `pandas.ewm(adjust=False)`替代SQLite SMA
- 仓位映射 T=65~80 渐变(无悬崖), T=80~100 从60%渐降到0%
- 跌停从 `daily_kline` 估算(limit_up_pool只有涨停)

### L2: 板块轮动引擎 (`engines/sector_rotation.py`, ~460行)

类 `SectorRotationEngine`:
- `calc_sector_heat(date)` → 472板块全量，5维度合成热度评分
- `identify_leaders(date, top_sectors)` → 三级龙头(涨停/资金/趋势)
- `run(date)` → 写入 `sector_rotation` + `leader_stocks` 表

**评分维度**: 资金连续流入(30%)+斜率(15%)+涨幅(15%)+均线多头占比(25%)+龙头强度(15%)
**阶段判断**: 连续≥5日→主战场, ≥3→潜力, 其余→观察

## 关键数据表

### 1. ths_member — 板块-成分股映射表
```
  ts_code   TEXT PRIMARY KEY   -- 板块代码 (e.g. 885431.TI)
  con_code  TEXT PRIMARY KEY   -- 成分股代码 (e.g. 000009.SZ)
  con_name  TEXT               -- 成分股名称
```
- **来源**: `pro.ths_member(ts_code='xxx.TI')`
- **覆盖**: 概念板块(885xxx/886xxx) + 行业板块(881xxx) ≈ 472板块
- **用途**: L2板块内均线向上占比计算、龙头股板块归属映射

### 2. sector_moneyflow_ths — 概念板块资金流向
```
  trade_date, sector_code, sector_name, lead_stock,
  sector_pct_change, net_amount, inflow_amount, outflow_amount, ...
```
- **来源**: `pro.moneyflow_cnt_ths(trade_date='YYYYMMDD')`
- **回填**: 至少80个交易日
- **用途**: L2板块连续资金流入天数、累计净流入

### 3. industry_moneyflow_ths — 行业板块资金流向
- **来源**: `pro.moneyflow_ind_ths(trade_date='YYYYMMDD')`
- **用途**: L2行业级别交叉验证

### 4. 三层决策新表 (migrations/004_create_three_layer_tables.sql)
```
  market_temperature       -- L1大盘温度评分历史
  sector_rotation          -- L2板块轮动评分
  leader_stocks            -- L2龙头股候选池
  decision_log             -- 三层融合决策日志
  valuation_daily_signal   -- L3估值每日信号
  drawdown_log             -- 风控回撤日志
  valuation_sector_config  -- 行业估值配置(25行默认值)
```

## 首次搭建步骤

### Step 1: 采集板块列表
```python
import tushare as ts
pro = ts.pro_api()

# 概念板块
df_concept = pro.ths_index(type='N', exchange='A')

# 行业板块  
df_industry = pro.ths_index(type='I', exchange='A')
```

### Step 2: 采集板块-成分股映射
```python
# 对每个板块代码调用
df = pro.ths_member(ts_code='885431.TI')
# 写入 ths_member 表
df.to_sql('ths_member', conn, if_exists='append', index=False)
```

**需要跳过的板块**: 
- 融资融券(>2000只, 非真实概念)
- ST板块、新股与次新股、注册制次新股(过渡性)
- 样本股/成份股类指数

### Step 3: 回填板块资金流历史
```python
for trade_date in trade_days:
    df = pro.moneyflow_cnt_ths(trade_date=trade_date)
    df.to_sql('sector_moneyflow_ths', conn, if_exists='append', index=False)
```

### Step 4: 创建三层决策新表
```bash
cd ~/my_quant_system
sqlite3 stock_data.db < migrations/004_create_three_layer_tables.sql
```

### Step 5: 注册每日增量cron
```python
# no_agent cron, 每天16:00运行
# 脚本: daily_sector_moneyflow.py
# 采集当日的概念+行业板块资金流向
```

## 关键SQL查询模板

### 连续N日资金流入的概念板块
```sql
SELECT sector_code, sector_name, 
       COUNT(*) as days_positive,
       SUM(net_amount) as cum_net
FROM sector_moneyflow_ths 
WHERE net_amount > 0 
  AND trade_date >= date('now', '-5 days')
GROUP BY sector_code
HAVING days_positive >= 3
ORDER BY cum_net DESC;
```

### 板块内均线向上个股占比
```sql
-- 需要 ths_member + daily_kline 联动
WITH sector_stocks AS (
    SELECT con_code, '885431.TI' as sector_code
    FROM ths_member WHERE ts_code = '885431.TI'
),
stock_ma AS (
    SELECT s.con_code, k.close,
           AVG(k.close) OVER w5 as ma5,
           AVG(k.close) OVER w20 as ma20
    FROM sector_stocks s
    JOIN daily_kline k ON s.con_code = k.stock_code
    WHERE k.date >= date('now', '-20 days')
    WINDOW w5 AS (PARTITION BY k.stock_code ORDER BY k.date ROWS 4 PRECEDING),
           w20 AS (PARTITION BY k.stock_code ORDER BY k.date ROWS 19 PRECEDING)
)
SELECT 
    SUM(CASE WHEN ma5 > ma20 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) as ratio_above_ma20
FROM stock_ma WHERE date = (SELECT MAX(date) FROM daily_kline);
```

### 龙头股识别（板块内涨停+资金）
```sql
SELECT m.con_code, m.con_name,
       k.pct_change,
       mf.main_net_amt
FROM ths_member m
JOIN daily_kline k ON m.con_code = k.stock_code AND k.date = '20260706'
JOIN moneyflow_daily mf ON m.con_code = mf.stock_code AND mf.date = '20260706'
WHERE m.ts_code = '885431.TI'
  AND k.pct_change > 9.5  -- 涨停阈值
ORDER BY mf.main_net_amt DESC;
```

## 常见问题

### P1. 数据格式不一致
`sector_moneyflow_ths` 原数据可能有 `YYYY-MM-DD` 和 `YYYYMMDD` 混合格式。
**修复**: 统一删除带横杠的老数据（已被YYYYMMDD覆盖）。

### P2. 板块分类层次
同花顺板块分三级:
- **概念板块** (885xxx.TI, 886xxx.TI) — 适合轮动分析, ~382个
- **行业板块** (881xxx.TI) — 申万-like分类, ~90个
- **子行业** (884xxx.TI) — 太细, 可选

### P3. 资金流数据时效
Tushare 的 `moneyflow_cnt_ths` 每天盘后约17:00~18:00更新。
cron设在 `45 18 * * 1-5`（板块资金流）和 `30 18 * * 1-5`（大盘资金流）。

## 依赖
- Tushare pro API (5000积分以上)
- Hermes cron (no_agent模式)
- Python 3.11 + pandas + numpy
